<?php
include 'dbcon1.php';

$id = $_GET['id'];
header('location:showemp.php');
//$id = $_GET['id'];

$deletequery ="delete from emppersonaldetail where id=$id";
$query =mysqli_query($con,$deletequery);


if($query)
{


    
  ?>  
<script>
alert('data Delete');
</script>

<?php
header('location:showemp.php');
}
else
{
  ?>
<script>
alert('data  not Delete');
</script>
<?php
}

?>



?>